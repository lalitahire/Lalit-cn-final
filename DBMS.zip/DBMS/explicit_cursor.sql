declare
rol1 O_Rollcall.roll_no%type;
name1 O_Rollcall.name%type;
age1 O_Rollcall.age%type;
marks1 O_Rollcall.marks%type;
Cursor expli_cur is 
 select roll_no,name,age,marks from O_Rollcall;
begin
open expli_cur;
loop
fetch expli_cur into rol1,name1,age1,marks1;
exit when expli_cur%notfound;
insert into N_Rollcall values(rol1,name1,age1,marks1);
end loop;
dbms_output.put_line('inserted record');
close expli_cur;
end;
/
