declare
rol1 O_Rollcall.roll_no%type;
name1 O_Rollcall.name%type;
age1 O_Rollcall.age%type;
marks1 O_Rollcall.marks%type;
begin
select roll_no,name,age,marks into rol1,name1,age1,marks1 from O_Rollcall where roll_no=002;
insert into N_Rollcall values(rol1,name1,age1,marks1);
dbms_output.put_line('completed');
end;
/
