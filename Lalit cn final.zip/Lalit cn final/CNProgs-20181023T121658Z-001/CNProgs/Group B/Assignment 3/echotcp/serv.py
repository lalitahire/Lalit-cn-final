import socket

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

sock.bind(('127.0.0.1', 23001))
sock.listen(5)

while 1:

	clisock, (ip, port) = sock.accept()

	print "ip: " + ip + ", port: "+ str(port)

	str1 = clisock.recv(100)
	print str1

	clisock.send("hello from server")

	clisock.close()














